import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import DateFormat class

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List Dashboard',
      debugShowCheckedModeBanner: false, // Remove debug banner
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ToDoListDashboard(),
    );
  }
}

class ToDoListDashboard extends StatefulWidget {
  const ToDoListDashboard({super.key});

  @override
  _ToDoListDashboardState createState() => _ToDoListDashboardState();
}

class _ToDoListDashboardState extends State<ToDoListDashboard> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _taskController = TextEditingController();
  List<Task> tasks = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Welcome to To Do List Dashboard',
          textAlign: TextAlign.center, // Center align the title
        ),
        centerTitle: true, // Center the title
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: const Text('Dashboard'),
              onTap: () {
                Navigator.pop(context); // Close the drawer
                // Add your navigation logic here for Dashboard
              },
            ),
            // ListTile(
            //   title: const Text('Activity'),
            //   onTap: () {
            //     Navigator.pop(context); // Close the drawer
            //     // Add your navigation logic here for Activity
            //   },
            // ),
            // ListTile(
            //   title: const Text('To Do List'),
            //   onTap: () {
            //     Navigator.pop(context); // Close the drawer
            //     // Add your navigation logic here for To Do List
            //
            //   },
           // ),

            ListTile(
              title: const Text('Project'),
              onTap: () {
                Navigator.pop(context); // Close the drawer
                // Add your navigation logic here for Project
              },
            ),
              ListTile(
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context); // Close the drawer
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SettingsScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Container(
        color: Colors.blue[100], // Light blue background color
        child: Column(
          children: [
            _buildTaskInput(),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      '${tasks[index].name}: ${tasks[index].title}',
                      style: TextStyle(
                        decoration: tasks[index].completed
                            ? TextDecoration.lineThrough
                            : null,
                      ),
                    ),
                    subtitle: Text(
                      'Category: ${tasks[index].category} | Due: ${DateFormat('yyyy-MM-dd HH:mm').format(tasks[index].dateTime!)}',
                    ),
                    leading: IconButton(
                      icon: Icon(
                        tasks[index].completed
                            ? Icons.check_circle
                            : Icons.radio_button_unchecked,
                        color: tasks[index].completed
                            ? Colors.green
                            : Colors.blue,
                      ),
                      onPressed: () {
                        setState(() {
                          tasks[index].completed = !tasks[index].completed;
                        });
                      },
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      color: Colors.red,
                      onPressed: () {
                        setState(() {
                          tasks.removeAt(index);
                        });
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              icon: const Icon(Icons.input),
              color: Colors.blue,
              onPressed: () {
                _showAddTaskDialog(context); // Trigger input dialog
              },
            ),
            IconButton(
              icon: const Icon(Icons.output),
              color: Colors.blue,
              onPressed: () {
                // Display all tasks added by the user
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('All Tasks'),
                      content: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: tasks.map((task) {
                            return ListTile(
                              title: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Name: ${task.name}'),
                                  Text('Category: ${task.category}'),
                                  Text('Task: ${task.title}'),
                                  Text('Due: ${DateFormat('yyyy-MM-dd HH:mm').format(task.dateTime!)}'),
                                ],
                              ),
                              trailing: task.completed ? const Icon(Icons.check_circle, color: Colors.green) : null,
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.person),
              color: Colors.blue,
              onPressed: () {
                // Log in respective users (placeholder logic)
                // You can replace this with your desired authentication logic
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: const Text('User Profile'),
                      content: TextField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          hintText: 'Enter username...',
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: const Text('Cancel'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Set the current user name
                            String userName = _nameController.text;
                            print('Logged in as: $userName');
                            Navigator.pop(context);
                          },
                          child: const Text('Log In'),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Add your FloatingActionButton onPressed logic here
        },
        label: const Text('To Do'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  Widget _buildTaskInput() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (tasks.isNotEmpty)
            const Text(
              'Tasks:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _showAddTaskDialog(BuildContext context) async {
    TextEditingController taskController = TextEditingController();
    DateTime? selectedDateTime;
    String? selectedCategory;

    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add Task'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  hintText: 'Enter your name...',
                ),
              ),
              DropdownButtonFormField<String>(
                value: selectedCategory,
                onChanged: (newValue) {
                  setState(() {
                    selectedCategory = newValue;
                  });
                },
                items: ['Personal', 'Work', 'Project']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                decoration: const InputDecoration(
                  hintText: 'Select category...',
                ),
              ),
              TextField(
                controller: taskController,
                decoration: const InputDecoration(
                  hintText: 'Enter task...',
                ),
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.calendar_today),
                    color: Colors.blue,
                    onPressed: () {
                      _selectDate(context, (DateTime pickedDate) {
                        selectedDateTime = pickedDate;
                      });
                    },
                  ),
                  if (selectedDateTime != null)
                    Text(
                      'Selected Date: ${DateFormat('yyyy-MM-dd HH:mm').format(selectedDateTime!)}',
                      style: const TextStyle(fontSize: 16),
                    ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                _addTask(_nameController.text, taskController.text, selectedDateTime, selectedCategory); // Pass user's name and selected category
                Navigator.pop(context);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _selectDate(BuildContext context, Function(DateTime) onSelect) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      if (pickedTime != null) {
        onSelect(DateTime(pickedDate.year, pickedDate.month, pickedDate.day, pickedTime.hour, pickedTime.minute));
      }
    }
  }

  void _addTask(String name, String taskTitle, DateTime? dateTime, String? category) {
    setState(() {
      if (taskTitle.isNotEmpty) {
        tasks.add(Task(name: name, title: taskTitle, dateTime: dateTime, category: category ?? 'Personal'));
      }
    });
  }
}

class Task {
  String name;
  String title;
  bool completed;
  DateTime? dateTime;
  String category;

  Task({required this.name, required this.title, this.completed = false, this.dateTime, required this.category});
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Notification Preferences'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const NotificationPreferencesScreen()),
              );
            },
          ),
          ListTile(
            title: const Text('Account Settings'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AccountSettingsScreen()),
              );
            },
          ),
          ListTile(
            title: const Text('Theme Preferences'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ThemePreferencesScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class NotificationPreferencesScreen extends StatefulWidget {
  const NotificationPreferencesScreen({super.key});

  @override
  _NotificationPreferencesScreenState createState() =>
      _NotificationPreferencesScreenState();
}

class _NotificationPreferencesScreenState
    extends State<NotificationPreferencesScreen> {
  bool receiveToDoNotifications = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Preferences'),
      ),
      body: SwitchListTile(
        title: const Text('Receive To-Do Notifications'),
        value: receiveToDoNotifications,
        onChanged: (bool value) {
          setState(() {
            receiveToDoNotifications = value;
          });
        },
      ),
    );
  }
}

class AccountSettingsScreen extends StatelessWidget {
  const AccountSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account Settings'),
      ),
      body: Column(
        children: [
          ListTile(
            title: const Text('Change Password'),
            onTap: () {
              // Navigate to Change Password screen
            },
          ),
          ListTile(
            title: const Text('Logout'),
            onTap: () {
              // Perform logout action
            },
          ),
        ],
      ),
    );
  }
}

class ThemePreferencesScreen extends StatefulWidget {
  const ThemePreferencesScreen({super.key});

  @override
  _ThemePreferencesScreenState createState() => _ThemePreferencesScreenState();
}

class _ThemePreferencesScreenState extends State<ThemePreferencesScreen> {
  String selectedTheme = 'light';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Theme Preferences'),
      ),
      body: Column(
        children: [
          RadioListTile<String>(
            title: const Text('Light Theme'),
            value: 'light',
            groupValue: selectedTheme,
            onChanged: (String? value) {
              if (value != null) {
                setState(() {
                  selectedTheme = value;
                });
              }
            },
          ),
          RadioListTile<String>(
            title: const Text('Dark Theme'),
            value: 'dark',
            groupValue: selectedTheme,
            onChanged: (String? value) {
              if (value != null) {
                setState(() {
                  selectedTheme = value;
                });
              }
            },
          ),
        ],
      ),
    );
  }
}